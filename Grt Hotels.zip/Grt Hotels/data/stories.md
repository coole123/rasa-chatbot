## hotelbot
* greet
  - utter_grtbot
  - utter_Names
* name_of_customer
  - utter_email_of_customer
* email_of_customer
  - utter_message_question
* existing
  - utter_existing
* confirm
  - utter_confirm_value
* confirmvalue
  - action_confirmation_value
  - action_submit_value
  - utter_stay
* New_booking
  - utter_ask_book_room
* affirm
  - utter_from_date
* from_date
  - utter_to_date
* to_date
  - utter_room
* rooms
  - utter_slot_value
  - action_submits
  - utter_type_hotel
* goodbye
  - utter_mood
* feedback
  - utter_thoughts
* feedback_given
  - action_all_information
  - utter_feed_backs
* mood_great
  - utter_happy

## web information
* web_information
  - utter_dynamic_link

## emails the details
* get_email_details
  - action_send_mail
  - utter_value_email

## basic
* Basic
  - action_all_information
  - action_carousel
* type
  - utter_hotel_description_Basic
  - utter_quick_replies

## elite
* Elite
  - action_all_information
  - action_carousel
* type
  - utter_hotel_description_elite
  - utter_quick_replies

## delux
* Delux
  - action_all_information
  - action_carousel
* type
  - utter_hotel_description_delux
  - utter_quick_replies

## YES
* Y
  - utter_dynamic_link

## NO
* N
  - utter_Names

## submit of total data of the customer
* submits
  - action_send_mail

## action no
* no
  - utter_no_value

## phone
* ask_phone
  - utter_phone_number
* phone_number
  - utter_stay
